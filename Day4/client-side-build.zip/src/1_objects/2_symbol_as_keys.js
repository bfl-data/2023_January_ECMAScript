// var person = {
//     id: 1,
//     name: "Manish",
//     username: "ManishS",
//     password: "ManishS",
//     address: {
//         state: "MH",
//         pin: 411021
//     },
//     display: function () {
//         console.log(this);
//     }
// };

var username = Symbol("username");
var password = Symbol("password");

var person = {
    id: 1,
    name: "Manish",
    [username]: "ManishS",
    [password]: "ManishS",
    address: {
        state: "MH",
        pin: 411021
    },
    display: function () {
        console.log(this);
    }
};

console.log(person);
console.log(person[username]);
console.log(person[password]);

const person_JSON = JSON.stringify(person);
console.log(person_JSON);