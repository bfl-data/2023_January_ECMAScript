// // // Eager Execution
// // function getId() {
// //     console.log("Hello from getId Function");
// // }

// // // Lazy Execution
// // function* getIdGenerator() {
// //     console.log("Hello from Generator Function");
// // }

// // getId();
// // getIdGenerator();

// // --------------------------------

// // function* getIdGenerator() {
// //     console.log("Hello from Generator Function");
// // }

// // let seq = getIdGenerator();
// // // console.log(seq);
// // console.log(seq.next());

// // // --------------------------------

// // function* getIdGenerator() {
// //     console.log("Hello from Generator Function");
// //     yield 1;
// //     yield 2;
// // }

// // let seq = getIdGenerator();
// // // console.log(seq);
// // console.log(seq.next());
// // console.log(seq.next());

// // --------------------------------

// function* getIdGenerator() {
//     console.log("First yield");
//     yield 1;
//     console.log("Second yield");
//     yield 2;
//     console.log("Third yield");
//     yield 3;
//     console.log("Last line of Generator Function");
// }

// let seq = getIdGenerator();
// console.warn("Starting Execution");
// console.log(seq.next());
// console.warn("Pause....");
// console.log(seq.next());
// console.warn("Pause....");
// console.log(seq.next());
// console.warn("Pause....");
// console.log(seq.next());

// ------------------------------------

class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];
    //     }   
    // }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }
}

let ordersQueue = new Queue();
ordersQueue.push("Order Id: 1");
ordersQueue.push("Order Id: 2");
ordersQueue.push("Order Id: 3");

for (const order of ordersQueue) {
    console.log(order);
}
