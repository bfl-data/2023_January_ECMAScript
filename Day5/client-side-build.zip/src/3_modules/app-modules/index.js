import { square } from './mone';
import { check } from './mtwo';
import { test } from './mthree';

export const app = {
    square, check, test
};