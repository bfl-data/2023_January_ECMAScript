export function check(x) {
    console.warn("From mtwo.js file");
    return `Checked: ${x}`;
}