// let myMap = new Map();

// // console.log(myMap);
// // console.log(typeof myMap);
// // console.log(myMap.size);

// const o = {id:1};
// const f = function() {}
// const s = Symbol("new key");

// myMap.set('the string', 'This is the value for the string key');
// myMap.set(o, 'This is the value for the object key');
// myMap.set(f, 'This is the value for the function key');
// myMap.set(s, 'This is the value for the symbol key');

// // console.log(myMap);
// // console.log(myMap.size);

// // console.log(myMap.get('the string'));
// // console.log(myMap.get(o));
// // console.log(myMap.get(f));
// // console.log(myMap.get(s));

// // for (const pair of myMap) {
// //     console.log(pair);
// // }

// // for (const key of myMap.keys()) {
// //     console.log(key);
// // }

// for (const value of myMap.values()) {
//     console.log(value);
// }

var phoneDirectory = [
    { name: "Manish", phone: 123456 },
    { name: "Abhijeet", phone: 654321 }
];

var directory = {
    Manish: 123456,
    Abhijeet: 123456
};

var contacts = [];
contacts["Manish"] = 123456;
contacts["Abhijeet"] = 654321;

// for (const key in contacts) {
//     console.log(key == "Manish")
// }

// var phoneDirectoryMap = new Map();
// phoneDirectoryMap.set("Manish", 123456);
// phoneDirectoryMap.set("Abhijeet", 654321);

// console.log('size of the map is', phoneDirectoryMap.size);
// console.log(phoneDirectoryMap.has("Manish"));

// // phoneDirectoryMap.delete("Manish");
// phoneDirectoryMap.clear();
// console.log(phoneDirectoryMap.has("Manish"));

var directoryMap = new Map(Object.entries(directory));
console.log(directoryMap);
