// import './1_datatypes/1_declarations';
// import './1_datatypes/2_es6-declarations';
// import './1_datatypes/3_es6-const';
// import './1_datatypes/4_datatypes';
// import './1_datatypes/5_operators';
// import './1_datatypes/6_symbols';

// import './2_functions/1_fn-creation';
import './2_functions/2_fn-parameters';
