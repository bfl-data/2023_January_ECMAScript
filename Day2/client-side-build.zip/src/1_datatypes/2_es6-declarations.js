'use strict'

// let a = 10;
// console.log("a is: ", a);

// let b;
// b = 20;
// console.log("b is: ", b);

// ------------------------------ Hoisting
// Hoisting - Hoisting is not supported

// a = 10;             
// console.log("a is: ", a);
// let a;

// ------------------------------ Not Typesafe

// let a = 10;
// console.log("a is: ", a);
// console.log("type of a: ", typeof a);

// a = "Manish";
// console.log("a is: ", a);
// console.log("type of a: ", typeof a);

// -------------------------------------
// You cannot create a variable with same name using let keyword, in same scope

// let a = 10;
// let a = "Manish";
// console.log("a is: ", a);
// console.log("type of a: ", typeof a);

// ------------------------------------------------------
// ECMASCRIPT 2015, with let keyword we get
// Global Scope (Global to the module or file)
// Function (Local) Scope
// Block Scope

// let a = 10;

// function test() {
//     if (true) {
//         let a = 100;                    // Local Variable (Block Scoped)
//         console.log("Inside block(), a is: ", a);
//     }
//     console.log("Inside test(), a is: ", a);
// }

// test();
// console.log("Outside test(), a is:", a);

var i = "Hello";
console.log("Before, i:", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside loop, i:", i);
}

console.log("After, i:", i);
