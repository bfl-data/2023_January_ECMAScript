// We cannot specify the type while declaring the variable
// Type of the variable will be implicitly defined at runtime
// We can provide any value to any variable
// We can use any operator with any operand type

// var result1 = 10 * true;
// console.log(result1);

// var result2 = 10 * 'abc';
// console.log(result2);

// console.log(true && "abc");
// console.log(true ? "text-info" : "");

// If isSelected(), returns true, I want to apply a CSS class to my HTML Element

{/* <h2 class={{isSelected() && "text-info" || "text-danger"}}></h2> */ }
{/* <h2 className={isSelected() && "text-info" || "text-danger"}></h2> */ }

var obj;
// var obj = undefined;
// var obj = null;
// var obj = { id: 1 };

// if ((obj == null) || (obj == undefined))
//     console.log("object is null or undefined");
// else
//     console.log("object is:", obj);

// if (!obj)
//     console.log("object is null or undefined");
// else
//     console.log("object is:", obj);

// --------------------------------------------- Compare
// let a = 10;
// let b = "10";

// console.log(typeof a);
// console.log(typeof b);

// console.log(a == b);              // Abstract Equality
// console.log(a === b);              // Strict Equality

let a = { id: 0 };
let b = { id: 0 };

console.log(a == b);              // Abstract Equality
console.log(a === b);              // Strict Equality

var c = b;
console.log(c == b);                // Abstract Equality
console.log(c === b);                // Strict Equality