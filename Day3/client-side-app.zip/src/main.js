// import './1_functions/1_rest-and-spread';
// import './1_functions/2_pure-and-impure';
// import './1_functions/3_using-callbacks';
// import './1_functions/4_fn-currying';
// import './1_functions/5_closure';
// import './1_functions/6_hof';
import './1_functions/7_fn-context';
