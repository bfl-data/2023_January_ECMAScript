// var count = 0;

// function next() {
//     return count += 1;
// }

// setInterval(() => {
//     console.log(next());
// }, 1000);

// setTimeout(() => {
//     count = "abc";
// }, 4000);

// ------------------------------

// function next() {
//     var count = 0;
//     return count += 1;
// }

// setInterval(() => {
//     console.log(next());
// }, 1000);

// setTimeout(() => {
//     count = "abc";
// }, 4000);

// ------------------------------

// function getNext() {
//     var count = 0;

//     function next() {
//         return count += 1;
//     }

//     return next;
// }

// const next = getNext();

// setInterval(() => {
//     console.log(next());
// }, 1000);

// const next = (function getNext() {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// setInterval(() => {
//     console.log(next());
// }, 1000);

// const counter = (function getNext() {
//     var count = 0;

//     function getCount() {

//     }

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// setInterval(() => {
//     console.log(counter.next());
// }, 1000);


// setInterval(() => {
//     console.log(counter.prev());
// }, 5000);