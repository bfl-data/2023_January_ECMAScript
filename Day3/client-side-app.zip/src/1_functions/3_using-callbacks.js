// Synchronous

// function getString() {
//     const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // var s = getString();
// // console.log(s);

// setInterval(() => {
//     var s = getString();
//     console.log(s);
// }, 2000);

// Call 1 = 1000
// Call 2 = 3000
// Call 3 = 1000

// -------------------------------

function pushString(cb) {
    setInterval(function () {
        const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

pushString(function (s) {
    console.log(s);
});