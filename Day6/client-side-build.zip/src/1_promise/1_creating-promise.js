// function pushData(cb) {
//     setTimeout(function () {
//         cb(1000);
//     }, 5000)
// }

// pushData((data) => {
//     console.log("Result: ", data);
// });

function getData() {
    var promise = new Promise((resolve, reject) => {
        // Async Code
        setTimeout(function () {
            resolve(1000);
        }, 5000)
    });
    return promise;
}

var p = getData();

// p.then((data) => {
//     console.log("Result: ", data);
// }, (err) => {
//     console.error("Error: ", err);
// });

// p.then((data) => {
//     console.log("Result: ", data);
// }).catch((err) => {
//     console.error("Error: ", err);
// });

p.then((data) => {
    console.log("Result: ", data);
}).catch((err) => {
    console.error("Error: ", err);
}).finally(() => {
    console.warn("Finally always executes...");
});