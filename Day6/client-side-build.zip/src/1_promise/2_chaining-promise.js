function firstMethod() {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('first method completed....');
            resolve({ first: 'added from first method' });
        }, 2000)
    });
    return promise;
}

function secondMethod(data) {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('second method completed....');
            // resolve({ ...data, second: 'added from second method' });
            reject("Second call failed...");
        }, 3000)
    });
    return promise;
}

function thirdMethod(data) {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('third method completed....');
            resolve({ ...data, third: 'added from third method' });
        }, 1000)
    });
    return promise;
}

// firstMethod().then(secondMethod).then(thirdMethod).then(data => {
//     console.log(data);
// }).catch(eMsg => {
//     console.error(eMsg);
// });

(async function () {
    try {
        var r1 = await firstMethod();
        var r2 = await secondMethod(r1);
        var r3 = await thirdMethod(r2);
        console.log(r3);
    } catch (eMsg) {
        console.error(eMsg);
    }
})();