// import './1_promise/1_creating-promise';
// import './1_promise/2_chaining-promise';
import './1_promise/3_promise-methods';

// import './2_ajax/dom-handler';